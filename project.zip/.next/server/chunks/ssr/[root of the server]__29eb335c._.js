module.exports = {

"[next]/internal/font/google/archivo_20891c80.module.css [app-rsc] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "className": "archivo_20891c80-module__7merVG__className",
  "variable": "archivo_20891c80-module__7merVG__variable",
});
}}),
"[next]/internal/font/google/archivo_20891c80.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$archivo_20891c80$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/archivo_20891c80.module.css [app-rsc] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$archivo_20891c80$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Archivo', 'Archivo Fallback'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$archivo_20891c80$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$archivo_20891c80$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}}),
"[project]/src/components/layout/Sidebar/Sidebar.jsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/layout/Sidebar/Sidebar.jsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/layout/Sidebar/Sidebar.jsx <module evaluation>", "default");
}}),
"[project]/src/components/layout/Sidebar/Sidebar.jsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/layout/Sidebar/Sidebar.jsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/layout/Sidebar/Sidebar.jsx", "default");
}}),
"[project]/src/components/layout/Sidebar/Sidebar.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$Sidebar$2f$Sidebar$2e$jsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/components/layout/Sidebar/Sidebar.jsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$Sidebar$2f$Sidebar$2e$jsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/src/components/layout/Sidebar/Sidebar.jsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$Sidebar$2f$Sidebar$2e$jsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/src/components/common/Section/Section.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
const Section = ({ children, className = "", noPaddingX = false })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${noPaddingX ? "px-0" : "lg:px-[86px] md:px-[56px] px-[16px]"} ${className}`,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/common/Section/Section.jsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = Section;
}}),
"[project]/src/constants/dummyData.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "BUILDING_TRUST_CARD": (()=>BUILDING_TRUST_CARD),
    "CERTIFIED_DIOMONDS_CARD": (()=>CERTIFIED_DIOMONDS_CARD),
    "CIRCULAR_FLOW_CONST": (()=>CIRCULAR_FLOW_CONST),
    "COMMITMENT_CARD": (()=>COMMITMENT_CARD),
    "CURVE_CARD_DATA": (()=>CURVE_CARD_DATA),
    "CUTTING_EDGE_TECH_DATA": (()=>CUTTING_EDGE_TECH_DATA),
    "HERO_SECTION_CONST": (()=>HERO_SECTION_CONST),
    "HOME_SERVICE_CONST": (()=>HOME_SERVICE_CONST),
    "IMAGE_GALLERY_CONST": (()=>IMAGE_GALLERY_CONST),
    "INNOVATION_CARD_DATA": (()=>INNOVATION_CARD_DATA),
    "MENUS": (()=>MENUS),
    "SOLUTIONS": (()=>SOLUTIONS),
    "STEPS": (()=>STEPS),
    "STOCK_INVENTORY": (()=>STOCK_INVENTORY),
    "TEMPLATE_DESIGN_CONST": (()=>TEMPLATE_DESIGN_CONST),
    "TESTIMONIAL_CONST": (()=>TESTIMONIAL_CONST)
});
const MENUS = [
    {
        label: "Home",
        url: "/"
    },
    {
        label: "About",
        url: "/about"
    },
    {
        label: "Promises",
        url: "/promises"
    },
    {
        label: "Service & Support",
        url: "/service-support"
    },
    {
        label: "Partnership Proposal",
        url: "/partnership-proposal"
    },
    {
        label: "Contact",
        url: "/contact"
    }
];
const HOME_SERVICE_CONST = [
    {
        id: 1,
        number: "01",
        title: "Exclusive Stock Selection",
        subtitle: "Finest Collection",
        hoverImg: "/images/stock-provision.png",
        content: "At JewelLabel, we ensure a seamless stock procurement process, providing businesses with high-quality jewelry collections tailored to market trends. Our expert product management team carefully curates, organizes, and maintains inventory, ensuring businesses have access to the latest designs while optimizing costs and supply chain efficiency."
    },
    {
        id: 2,
        number: "02",
        title: "Tailored Web Solutions",
        subtitle: "Designed to impress, built to perform",
        hoverImg: "/images/website.png",
        content: "Your online presence is your brand’s first impression. JewelLabel offers premium website design and development services, crafting visually stunning and highly functional e-commerce platforms. From intuitive navigation to secure payment gateways, we build websites that enhance user experience, drive conversions, and reflect your brand’s essence."
    },
    {
        id: 3,
        number: "03",
        title: "Result-Driven Marketing",
        subtitle: "Strategies that turn brands into legacies",
        hoverImg: "/images/marketing.png",
        content: "Success in the jewelry business goes beyond just products—it’s about storytelling. Our marketing and advertising services help brands connect with their audience through compelling campaigns, social media strategies, and targeted ads. Whether through digital or traditional channels, we ensure maximum brand visibility and customer engagement."
    },
    {
        id: 4,
        number: "04",
        title: "Unmatched Quality & Trust",
        subtitle: "The cornerstone of every creation",
        hoverImg: "/images/quality-trust.png",
        content: "At JewelLabel, quality is at the heart of everything we do. We provide ethically sourced, meticulously crafted jewelry that meets the highest industry standards. Our commitment to transparency, customer satisfaction, and authenticity fosters trust, ensuring businesses can confidently build their brand with us."
    }
];
const IMAGE_GALLERY_CONST = [
    "/images/templates/Template-1.png",
    "/images/templates/Template-2.png",
    "/images/templates/Template-3.png",
    "/images/templates/Template-4.png",
    "/images/templates/Template-5.png",
    "/images/templates/Template-6.png",
    "/images/templates/Template-7.png",
    "/images/templates/Template-8.png",
    "/images/templates/Template-9.png",
    "/images/templates/Template-10.png"
];
const TEMPLATE_DESIGN_CONST = [
    "/images/templates/template-1.webp",
    "/images/templates/template-2.webp",
    "/images/templates/template-3.webp",
    "/images/templates/template-4.webp",
    "/images/templates/template-5.webp"
];
const HERO_SECTION_CONST = [
    {
        title: "Your Diamond Jewellery Partner",
        subTitle: "Launch & grow your jewelry brand effortlessly with Jewel Label’s expertise!",
        btnText: "Schedule Call",
        rightSideTitle: "creating work that inspire"
    }
];
const STEPS = [
    {
        title: "End to End Solution",
        description: "We begin by discussing your goals, audience, and expectations to ensure our approach aligns perfectly with your vision.",
        imgUrl: "/images/end-to-end-solutions.png"
    },
    {
        title: "Hassle Free Experience",
        description: "We begin by discussing your goals, audience, and expectations to ensure our approach aligns perfectly with your vision.",
        imgUrl: "/images/hassle-free-experience.png"
    },
    {
        title: "Transparent Dealing",
        description: "We begin by discussing your goals, audience, and expectations to ensure our approach aligns perfectly with your vision.",
        imgUrl: "/images/transparent-dealing.png"
    },
    {
        title: "Time to Time Supply",
        description: "We begin by discussing your goals, audience, and expectations to ensure our approach aligns perfectly with your vision.",
        imgUrl: "/images/time-to-time-supply.png"
    },
    {
        title: "Crafting Timeless Design",
        description: "We begin by discussing your goals, audience, and expectations to ensure our approach aligns perfectly with your vision.",
        imgUrl: "/images/crafting-timeless-designs.png"
    },
    {
        title: "Certified Jewellery",
        description: "We begin by discussing your goals, audience, and expectations to ensure our approach aligns perfectly with your vision.",
        imgUrl: "/images/certified-jewellery.png"
    }
];
const TESTIMONIAL_CONST = [
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-1.png",
        name: "Esther Howard 1",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-2.png",
        name: "Devon Lane 2",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-3.png",
        name: "Theresa Webb 3",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-4.png",
        name: "Floyd Miles 4",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-5.png",
        name: "Jacob Jones 5",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-6.png",
        name: "Albert Flores 6",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-6.png",
        name: "Albert Flores 7",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-6.png",
        name: "Albert Flores 8",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-6.png",
        name: "Albert Flores 9",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-6.png",
        name: "Albert Flores 10",
        designation: "Digital Marketer"
    },
    {
        comments: "Vorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.",
        userImg: "images/users/profile-pic-6.png",
        name: "Albert Flores 11",
        designation: "Digital Marketer"
    }
];
const CUTTING_EDGE_TECH_DATA = {
    cards: [
        {
            cardTitle: "Sustainability Without Compromise",
            cardDescription: "Unlike mined diamonds, our lab-grown diamonds have a significantly lower carbon footprint and eliminate the environmental damage caused by traditional mining."
        },
        {
            cardTitle: "Innovation Meets Precision",
            cardDescription: "We collaborate with state-of-the-art laboratories that use controlled environments to simulate the earth’s natural diamond-growing process."
        }
    ]
};
const CURVE_CARD_DATA = [
    {
        title: "Your Success, Our Commitment",
        description: "Your wins are our wins. From day one, we walk beside you, ensuring you have the tools, support, and confidence to achieve more than you thought possible."
    },
    {
        title: "Sustainability with Purpose",
        description: "At Jewel Label, we believe in building a better future. Our eco-conscious practices not only reduce waste but also inspire your customers to trust in your brand’s values."
    },
    {
        title: "End-to-End Inventory Management",
        description: "Eliminate the burden of maintaining stock—Jewel Label provides and manages all your inventory needs."
    }
];
const INNOVATION_CARD_DATA = [
    {
        title: "Inventory-Free Business Model",
        description: "Clients don’t have to invest in creating or maintaining inventory; Jewel Label takes care of all stock requirements. Ensures a seamless supply chain without the hassle of stock management.",
        iconUrl: "/icons/Union.svg"
    },
    {
        title: "Customization at Scale",
        description: "Offers tailored label designs that align with your brand identity. Provides flexibility to adapt to diverse product lines or industries.",
        iconUrl: "/icons/scale.svg"
    },
    {
        title: "Centralized Control",
        description: "Manage all your label data and designs in one platform.Easy access to historical designs for consistency across products.",
        iconUrl: "/icons/control.svg"
    },
    {
        title: "Dedicated Support",
        description: "24/7 customer service to address issues quickly.Expert guidance on maximizing the platform’s potential for your business.",
        iconUrl: "/icons/support.svg"
    }
];
const CIRCULAR_FLOW_CONST = [
    {
        title: "Stock Provision & Customization",
        description: "Ready-to-sell lab-grown diamond jewelry with tailored customization to match",
        imgUrl: "/images/promises/stock-provision-and-customization.png"
    },
    {
        title: "Brand Identity & Web Development",
        description: "Create a compelling brand presence with logo design, packaging, and an e-commerce website.",
        imgUrl: "/images/promises/brand-identity.png"
    },
    {
        title: "Marketing & Lead Generation",
        description: "Drive sales with social media marketing, product photography, paid ads, and influencer collaborations.",
        imgUrl: "/images/promises/marketing-and-lead-generation.png"
    },
    {
        title: "Business Consultation & Growth Strategy",
        description: "Get expert insights on market trends, pricing, and scaling your business.",
        imgUrl: "/images/promises/business-consultation.png"
    },
    {
        title: "Capture Brilliance, Sell with Confidence",
        description: "Professional jewelry photography that enhances every intricate detail.",
        imgUrl: "/images/promises/capture-brilliance.png"
    },
    {
        title: "Luxury Packaging That Elevates Your Brand",
        description: "Custom premium packaging for a memorable unboxing experience.",
        imgUrl: "/images/promises/luxury-packaging.png"
    }
];
const COMMITMENT_CARD = [
    {
        title: "Precision Craftsmanship",
        description: "We use cutting-edge technology and expert artisans to design and manufacture flawless, high-quality jewelry that meets global standards."
    },
    {
        title: "Rigorous Quality Checks",
        description: "Each product undergoes a strict multi-point quality inspection, ensuring perfect cuts, clarity, and finishing before reaching you."
    }
];
const BUILDING_TRUST_CARD = [
    {
        title: "Authenticity Guarantee",
        description: "We provide detailed certifications with every piece, ensuring complete transparency and credibility."
    },
    {
        title: "Reliable Partnerships",
        description: " We prioritize long-term relationships by offering consistent quality, ethical practices, and seamless service, making us a trusted B2B jewelry partner."
    }
];
const CERTIFIED_DIOMONDS_CARD = [
    {
        title: "100% Real Diamonds",
        description: "Our lab-grown diamonds have the same physical, chemical, and optical properties as natural diamonds.",
        iconUrl: "/icons/control.svg"
    },
    {
        title: "International Certification",
        description: "Each diamond is certified by leading authorities like IGI (International Gemological Institute), GIA (Gemological Institute of America), and SGL (Solitaire Gem Labs), ensuring authenticity.",
        iconUrl: "/icons/support.svg"
    },
    {
        title: "Flawless Craftsmanship",
        description: "Using cutting-edge technology, we ensure each diamond has perfect clarity, cut, and color, rivaling the best mined diamonds.",
        iconUrl: "/icons/scale.svg"
    },
    {
        title: "Ethical & Sustainable",
        description: "Our diamonds are conflict-free and eco-friendly, making them the perfect choice for conscious consumers.",
        iconUrl: "/icons/control.svg"
    },
    {
        title: "Better Value, Same Brilliance",
        description: "Enjoy luxury without the premium price tag, as lab-grown diamonds offer better affordability compared to mined ones.",
        iconUrl: "/icons/support.svg"
    }
];
const SOLUTIONS = [
    {
        label: "Stock inventory",
        hoverImg: "images/services/stock-inventory.png",
        path: "stock-inventory"
    },
    {
        label: "website design & Development",
        hoverImg: "images/services/website-design-development.png",
        path: "website-design-development"
    },
    {
        label: "Adverting & Marketing",
        hoverImg: "images/services/adverting-marketing.png",
        path: "adverting-marketing"
    },
    {
        label: "Product packaging supply",
        hoverImg: "images/services/product-packaging-supply.png",
        path: "product-packaging-supply"
    }
];
const STOCK_INVENTORY = [
    {
        icon: "/icons/hand-picked.svg",
        title: "Handpicked & <br/> trend-driven designs"
    },
    {
        icon: "/icons/customization.svg",
        title: "Customization <br/> options available"
    },
    {
        icon: "/icons/inventory.svg",
        title: "Seamless inventory <br/> management"
    },
    {
        icon: "/icons/pricing.svg",
        title: "Wholesale pricing <br/> for bulk orders"
    }
];
}}),
"[project]/src/components/layout/Footer/Footer.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Section$2f$Section$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/Section/Section.jsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$dummyData$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/dummyData.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
;
;
;
const Footer = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Section$2f$Section$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        className: "grid grid-rows-3 bg-[#D9D9D9] pt-[27px] pb-[49px]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: "/icons/logo-horizontal.svg",
                    className: "object-contain"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Footer/Footer.jsx",
                    lineNumber: 10,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/Footer/Footer.jsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "flex justify-end gap-6",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$dummyData$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["MENUS"].map((menu, index)=>{
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                            href: menu.url,
                            className: "text-gray-700 hover:text-orange-500",
                            children: menu.label
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/Footer/Footer.jsx",
                            lineNumber: 17,
                            columnNumber: 17
                        }, this)
                    }, index, false, {
                        fileName: "[project]/src/components/layout/Footer/Footer.jsx",
                        lineNumber: 16,
                        columnNumber: 15
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/layout/Footer/Footer.jsx",
                lineNumber: 13,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-t border-dark justify-between mt-4 pt-4 flex",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: "© 2025 — Copyright all right reserved."
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/Footer/Footer.jsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Privacy Policy"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/Footer/Footer.jsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/Footer/Footer.jsx",
                lineNumber: 28,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/Footer/Footer.jsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = Footer;
}}),
"[project]/src/app/layout.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const e = new Error(`Could not parse module '[project]/src/app/layout.js'

Expected ',', got 'variable'`);
e.code = 'MODULE_UNPARSEABLE';
throw e;}}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-rsc] (ecmascript)").vendored['react-rsc'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}}),
"[project]/node_modules/next/dist/client/app-dir/link.js (client reference/proxy) <module evaluation>": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const { createClientModuleProxy } = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
__turbopack_context__.n(createClientModuleProxy("[project]/node_modules/next/dist/client/app-dir/link.js <module evaluation>"));
}}),
"[project]/node_modules/next/dist/client/app-dir/link.js (client reference/proxy)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const { createClientModuleProxy } = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
__turbopack_context__.n(createClientModuleProxy("[project]/node_modules/next/dist/client/app-dir/link.js"));
}}),
"[project]/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$28$client__reference$2f$proxy$29$__);
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__29eb335c._.js.map