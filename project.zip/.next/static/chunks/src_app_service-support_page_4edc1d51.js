(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_service-support_page_4edc1d51.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_service-support_page_4edc1d51.js",
  "chunks": [
    "static/chunks/_85222e29._.js"
  ],
  "source": "dynamic"
});
