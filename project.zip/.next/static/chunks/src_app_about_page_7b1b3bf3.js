(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_about_page_7b1b3bf3.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_about_page_7b1b3bf3.js",
  "chunks": [
    "static/chunks/node_modules_4ef95f3e._.js",
    "static/chunks/src_components_186cf8e4._.js"
  ],
  "source": "dynamic"
});
