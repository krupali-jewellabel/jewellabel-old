(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_promises_page_9d19abf0.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_promises_page_9d19abf0.js",
  "chunks": [
    "static/chunks/node_modules_834aedfd._.js",
    "static/chunks/src_e340c90c._.js"
  ],
  "source": "dynamic"
});
