(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_598cbcb5.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_598cbcb5.js",
  "chunks": [
    "static/chunks/src_f57e1d1d._.js",
    "static/chunks/node_modules_next_0766a282._.js",
    "static/chunks/node_modules_gsap_27523451._.js",
    "static/chunks/node_modules_framer-motion_dist_es_6186f1d5._.js",
    "static/chunks/node_modules_motion-dom_dist_es_7fc0833b._.js",
    "static/chunks/node_modules_b5036c55._.js"
  ],
  "source": "dynamic"
});
