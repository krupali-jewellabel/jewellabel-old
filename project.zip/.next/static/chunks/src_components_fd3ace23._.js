(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_components_fd3ace23._.js", {

"[project]/src/components/common/FeatureHeader/FeatureHeader.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$use$2d$in$2d$view$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/utils/use-in-view.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/Typography/Typography.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const FeatureHeader = ({ label, title, description, className })=>{
    _s();
    const FADE_DOWN = {
        show: {
            opacity: 1,
            y: 0,
            transition: {
                type: "spring"
            }
        },
        hidden: {
            opacity: 0,
            y: 18
        }
    };
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isInView = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$use$2d$in$2d$view$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInView"])(ref, {
        once: true
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
        ref: ref,
        className: `lg:mb-[80px] mb-[30px] ${className}`,
        initial: "hidden",
        animate: isInView ? "show" : "",
        variants: {
            hidden: {},
            show: {
                transition: {
                    staggerChildren: 0.1
                }
            }
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                variants: FADE_DOWN,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-[6px] items-center border border-[#E8EAEB] lg:p-[10px] p-[4px_8px] w-fit uppercase rounded-[64px] lg:mb-[15px] mb-[7px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                alt: "icon",
                                src: "icons/spark.svg",
                                height: 20,
                                width: 20
                            }, void 0, false, {
                                fileName: "[project]/src/components/common/FeatureHeader/FeatureHeader.jsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "p",
                                children: label
                            }, void 0, false, {
                                fileName: "[project]/src/components/common/FeatureHeader/FeatureHeader.jsx",
                                lineNumber: 32,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/common/FeatureHeader/FeatureHeader.jsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "h3",
                        className: "uppercase",
                        dangerouslySetInnerHTML: {
                            __html: title
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/FeatureHeader/FeatureHeader.jsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/common/FeatureHeader/FeatureHeader.jsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "h6",
                className: "mt-[24px]",
                children: description
            }, void 0, false, {
                fileName: "[project]/src/components/common/FeatureHeader/FeatureHeader.jsx",
                lineNumber: 42,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/common/FeatureHeader/FeatureHeader.jsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
};
_s(FeatureHeader, "DljcBprJKYjULUac3YKdUV9OwZQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$utils$2f$use$2d$in$2d$view$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInView"]
    ];
});
_c = FeatureHeader;
const __TURBOPACK__default__export__ = FeatureHeader;
var _c;
__turbopack_context__.k.register(_c, "FeatureHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/common/Section/Section.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
const Section = ({ children, className = "", noPaddingX = false })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${noPaddingX ? "px-0" : "lg:px-[86px] md:px-[56px] px-[16px]"} ${className}`,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/common/Section/Section.jsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
};
_c = Section;
const __TURBOPACK__default__export__ = Section;
var _c;
__turbopack_context__.k.register(_c, "Section");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/About/EmpoweringBrands.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/gsap/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$ScrollTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/gsap/ScrollTrigger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/Typography/Typography.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$FeatureHeader$2f$FeatureHeader$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/FeatureHeader/FeatureHeader.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Section$2f$Section$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/Section/Section.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const EmpoweringBrands = ()=>{
    _s();
    // Refs for the elements to animate
    const leftCardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const leftImageRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const rightCardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const rightImageRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].registerPlugin(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$ScrollTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollTrigger"]);
    const leftScroll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    //  useEffect(() => {
    //    gsap.fromTo(
    //      leftScroll.current,
    //      { x: 0 },
    //      { x: -500, duration: 1, ease: "power2.out", scrollTrigger: { trigger: leftScroll.current, start: "top 80%" } }
    //    );
    //  }, []);
    //  useEffect(() => {
    //    gsap.fromTo(
    //      leftCardRef.current,
    //      { x: 0 }, // Starting position
    //      { x: -100, duration: 1, ease: "power2.out" } // Move left by 100px
    //    );
    //    gsap.fromTo(
    //      leftImageRef.current,
    //      { x: 0 },
    //      { x: -100, duration: 1, ease: "power2.out" }
    //    );
    //    gsap.fromTo(
    //      rightImageRef.current,
    //      { x: 0 },
    //      { x: 100, duration: 1, ease: "power2.out" } // Move right by 100px
    //    );
    //    gsap.fromTo(
    //      rightCardRef.current,
    //      { x: 0 },
    //      { x: 100, duration: 1, ease: "power2.out" }
    //    );
    //  }, []); // Empty dependency array to run once on mount
    // Use an array to hold multiple refs
    const leftScrollRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    const rightScrollRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    const secondRightScrollRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    const secondLefttScrollRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmpoweringBrands.useEffect": ()=>{
            // Animate all elements in the leftScrollRefs array
            leftScrollRefs.current.forEach({
                "EmpoweringBrands.useEffect": (element)=>{
                    if (element) {
                        // Ensure the element exists
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].fromTo(element, {
                            x: 0
                        }, {
                            x: -500,
                            duration: 1,
                            ease: "power2.out",
                            scrollTrigger: {
                                trigger: element,
                                start: "top 80%"
                            }
                        });
                    }
                }
            }["EmpoweringBrands.useEffect"]);
            rightScrollRefs.current.forEach({
                "EmpoweringBrands.useEffect": (element)=>{
                    if (element) {
                        // Ensure the element exists
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].fromTo(element, {
                            x: 0
                        }, {
                            x: 500,
                            duration: 1,
                            ease: "power2.out",
                            scrollTrigger: {
                                trigger: element,
                                start: "top 80%"
                            }
                        });
                    }
                }
            }["EmpoweringBrands.useEffect"]);
            secondRightScrollRefs.current.forEach({
                "EmpoweringBrands.useEffect": (element)=>{
                    if (element) {
                        // Ensure the element exists
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].fromTo(element, {
                            x: 0
                        }, {
                            x: 400,
                            duration: 2,
                            delay: 1,
                            ease: "power2.out",
                            scrollTrigger: {
                                trigger: element,
                                start: "top 80%"
                            }
                        });
                    }
                }
            }["EmpoweringBrands.useEffect"]);
            secondLefttScrollRefs.current.forEach({
                "EmpoweringBrands.useEffect": (element)=>{
                    if (element) {
                        // Ensure the element exists
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].fromTo(element, {
                            x: 0
                        }, {
                            x: -300,
                            duration: 2,
                            delay: 1,
                            ease: "power2.out",
                            scrollTrigger: {
                                trigger: element,
                                start: "top 80%"
                            }
                        });
                    }
                }
            }["EmpoweringBrands.useEffect"]);
        }
    }["EmpoweringBrands.useEffect"], []);
    // Helper function to add elements to the refs array
    const addToLeftRefs = (el)=>{
        if (el && !leftScrollRefs.current.includes(el)) {
            leftScrollRefs.current.push(el);
        }
    };
    // Helper function for right-side elements
    const addToRightRefs = (el)=>{
        if (el && !rightScrollRefs.current.includes(el)) {
            rightScrollRefs.current.push(el);
        }
    };
    const addToSecondRightRefs = (el)=>{
        if (el && !secondRightScrollRefs.current.includes(el)) {
            secondRightScrollRefs.current.push(el);
        }
    };
    const addToSecondLeftRefs = (el)=>{
        if (el && !secondLefttScrollRefs.current.includes(el)) {
            secondLefttScrollRefs.current.push(el);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Section$2f$Section$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$FeatureHeader$2f$FeatureHeader$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                label: "technology",
                title: "Empowering brands"
            }, void 0, false, {
                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                lineNumber: 161,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-4 grid-rows-2 justify-items-center gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: addToSecondRightRefs,
                        className: "overflow-hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "/images/about/brand-1.png",
                            className: "h-[530px]"
                        }, void 0, false, {
                            fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                            lineNumber: 164,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: addToLeftRefs,
                        className: "bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "h4",
                                children: "Freedom from Inventory Worries"
                            }, void 0, false, {
                                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                                lineNumber: 170,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "h6",
                                className: "text-[#7A7A7A]",
                                children: "Focus on your vision while Jewel Label handles the rest. No inventory investment—just create and innovate!"
                            }, void 0, false, {
                                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                                lineNumber: 171,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-hidden",
                        ref: addToRightRefs,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "/images/about/brand-2.png",
                            className: "h-[530px]"
                        }, void 0, false, {
                            fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                            lineNumber: 177,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: addToSecondLeftRefs,
                        className: "bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "h4",
                                children: "Professional Web Design & Development"
                            }, void 0, false, {
                                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                                lineNumber: 183,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "h6",
                                className: "text-[#7A7A7A]",
                                children: "Jewel Label builds custom, high-converting websites for clients, ensuring a seamless online shopping experience that enhances brand credibility and sales."
                            }, void 0, false, {
                                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                                lineNumber: 186,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                        lineNumber: 179,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: addToRightRefs,
                        className: "bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "h4",
                                children: "Hassle-Free Business Setup"
                            }, void 0, false, {
                                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                                lineNumber: 196,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "h6",
                                className: "text-[#7A7A7A]",
                                children: "Entrepreneurs and businesses don’t need to worry about sourcing products, setting up a website, or marketing. Jewel Label handles everything from stock provision to branding."
                            }, void 0, false, {
                                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                                lineNumber: 197,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                        lineNumber: 192,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: addToLeftRefs,
                        className: "overflow-hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "/images/about/brand-3.png",
                            className: "h-[530px]"
                        }, void 0, false, {
                            fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                            lineNumber: 204,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                        lineNumber: 203,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: addToRightRefs,
                        className: "bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "h4",
                                children: "Logistics & Order Fulfillment"
                            }, void 0, false, {
                                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                                lineNumber: 210,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Typography$2f$Typography$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "h6",
                                className: "text-[#7A7A7A]",
                                children: "Smooth transportation and shipping solutions ensure that brands can deliver products efficiently, reducing operational stress."
                            }, void 0, false, {
                                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                                lineNumber: 211,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                        lineNumber: 206,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: "03"
                    }, void 0, false, {
                        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                        lineNumber: 216,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
                lineNumber: 162,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/About/EmpoweringBrands.jsx",
        lineNumber: 160,
        columnNumber: 5
    }, this);
};
_s(EmpoweringBrands, "LaEIp/dT+J0x32Lmq3o5sfPjnyU=");
_c = EmpoweringBrands;
const __TURBOPACK__default__export__ = EmpoweringBrands;
// <div className="grid grid-cols-4 gap-4">
// {/* <div className="bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]">
//   <h3 className="font-[700] text-[36px]">
//     Freedom from Inventory Worries
//   </h3>
//   <p className="text-[26px] font-[300] text-[#7A7A7A]">
//     Focus on your vision while Jewel Label handles the rest. No
//     inventory investment—just create and innovate!
//   </p>
// </div> */}
// <div className="...">
//   <img src="/images/about/brand-1.png" className="h-[530px] w-[450px]"/>
// </div>
// <div className="bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]">
//   <h3 className="font-[700] text-[36px]">
//     Professional Web Design & Development
//   </h3>
//   <p className="text-[26px] font-[300] text-[#7A7A7A]">
//     Jewel Label builds custom, high-converting websites for clients,
//     ensuring a seamless online shopping experience that enhances brand
//     credibility and sales.
//   </p>
// </div>
// {/* <div className="...">
//   <img src="/images/about/brand-2.png" className="h-[530px] w-[450px]"/>
// </div> */}
// {/* <div className="...">
//   <img src="/images/about/brand-3.png" className="h-[530px] w-[450px]"/>
// </div> */}
// {/* <div className="bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]">
//   <h3 className="font-[700] text-[36px]">Hassle-Free Business Setup</h3>
//   <p className="text-[26px] font-[300] text-[#7A7A7A]">
//     Entrepreneurs and businesses don’t need to worry about sourcing
//     products, setting up a website, or marketing. Jewel Label handles
//     everything from stock provision to branding.
//   </p>
// </div> */}
// <div className="...">
//   <img src="/images/about/brand-4.png" className="h-[530px] w-[450px]"/>
// </div>
// <div className="bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]">
//   <h3 className="font-[700] text-[36px]">
//     Logistics & Order Fulfillment
//   </h3>
//   <p className="text-[26px] font-[300] text-[#7A7A7A]">
//     Smooth transportation and shipping solutions ensure that brands can
//     deliver products efficiently, reducing operational stress.
//   </p>
// </div>
// </div>
{
/* <div
className="grid grid-cols-2 items-center justify-items-center gap-4"
initial={{ height: 0 }}
animate={{ height: "auto" }}
> */ }{
/* <div className="bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]">
  <h3 className="font-[700] text-[36px]">
    Freedom from Inventory Worries
  </h3>
  <p className="text-[26px] font-[300] text-[#7A7A7A]">
    Focus on your vision while Jewel Label handles the rest. No
    inventory investment—just create and innovate!
  </p>
</div> */ }{
/* <div className="...">
  <img
    src="/images/about/brand-1.png"
    className="h-[530px] w-[450px]"
  />
</div>
<div className="bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]">
  <h3 className="font-[700] text-[36px]">
    Professional Web Design & Development
  </h3>
  <p className="text-[26px] font-[300] text-[#7A7A7A]">
    Jewel Label builds custom, high-converting websites for clients,
    ensuring a seamless online shopping experience that enhances brand
    credibility and sales.
  </p>
</div> */ }{
/* <div className="...">
  <img src="/images/about/brand-2.png" className="h-[530px] w-[450px]"/>
</div> */ }{
/* <div className="...">
  <img src="/images/about/brand-3.png" className="h-[530px] w-[450px]"/>
</div> */ }{
/* <div className="bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]">
  <h3 className="font-[700] text-[36px]">Hassle-Free Business Setup</h3>
  <p className="text-[26px] font-[300] text-[#7A7A7A]">
    Entrepreneurs and businesses don’t need to worry about sourcing
    products, setting up a website, or marketing. Jewel Label handles
    everything from stock provision to branding.
  </p>
</div> */ }{
/* <div className="...">
  <img
    src="/images/about/brand-4.png"
    className="h-[530px] w-[450px]"
  />
</div>
<div className="bg-[#F7F8FA] rounded-[20px] p-[25px] flex flex-col justify-between h-[530px] w-[450px]">
  <h3 className="font-[700] text-[36px]">
    Logistics & Order Fulfillment
  </h3>
  <p className="text-[26px] font-[300] text-[#7A7A7A]">
    Smooth transportation and shipping solutions ensure that brands can
    deliver products efficiently, reducing operational stress.
  </p>
</div>
</div> */ }var _c;
__turbopack_context__.k.register(_c, "EmpoweringBrands");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_components_fd3ace23._.js.map