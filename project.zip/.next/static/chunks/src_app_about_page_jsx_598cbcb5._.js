(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_about_page_jsx_598cbcb5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_about_page_jsx_598cbcb5._.js",
  "chunks": [
    "static/chunks/node_modules_next_0766a282._.js",
    "static/chunks/node_modules_framer-motion_dist_es_f0e41fb7._.js",
    "static/chunks/node_modules_motion-dom_dist_es_7fc0833b._.js",
    "static/chunks/node_modules_gsap_27523451._.js",
    "static/chunks/node_modules_f9e09040._.js",
    "static/chunks/src_67186678._.js"
  ],
  "source": "dynamic"
});
