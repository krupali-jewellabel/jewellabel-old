(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_b078889f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_b078889f.js",
  "chunks": [
    "static/chunks/src_818f8813._.js",
    "static/chunks/node_modules_9b68960e._.js"
  ],
  "source": "dynamic"
});
