(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_f0e4c1a2.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_f0e4c1a2.js",
  "chunks": [
    "static/chunks/[root of the server]__3b28ce5b._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_31453530._.js",
    "static/chunks/node_modules_7a23c62a._.js",
    "static/chunks/src_17287526._.js"
  ],
  "source": "dynamic"
});
