(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_promises_page_jsx_b078889f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_promises_page_jsx_b078889f._.js",
  "chunks": [
    "static/chunks/_584abbca._.js"
  ],
  "source": "dynamic"
});
