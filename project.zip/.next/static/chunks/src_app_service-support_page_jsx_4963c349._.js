(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_service-support_page_jsx_4963c349._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_service-support_page_jsx_4963c349._.js",
  "chunks": [
    "static/chunks/_6ab498f6._.js"
  ],
  "source": "dynamic"
});
