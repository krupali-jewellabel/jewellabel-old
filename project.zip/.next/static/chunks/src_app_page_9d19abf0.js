(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_9d19abf0.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_9d19abf0.js",
  "chunks": [
    "static/chunks/src_c0b09e0a._.js",
    "static/chunks/node_modules_9b68960e._.js"
  ],
  "source": "dynamic"
});
