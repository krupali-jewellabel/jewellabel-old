(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_about_page_jsx_b078889f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_about_page_jsx_b078889f._.js",
  "chunks": [
    "static/chunks/node_modules_4ef95f3e._.js",
    "static/chunks/src_components_81ad06ba._.js"
  ],
  "source": "dynamic"
});
